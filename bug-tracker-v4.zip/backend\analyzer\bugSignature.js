import crypto from "crypto";

export function createBugSignature(item, url) {
  // Normalize the URL to prevent "http://localhost" vs "http://localhost/" issues
  const cleanUrl = url.split('?')[0].replace(/\/$/, "");
  
  const base = [
    item.type || "UNKNOWN",
    item.message?.replace(/\d+/g, ""), // Remove dynamic numbers (IDs)
    cleanUrl
  ].join("|");

  return crypto.createHash("sha1").update(base).digest("hex");
}