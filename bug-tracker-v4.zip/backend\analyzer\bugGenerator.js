export function generateBugs(analysis, appUrl) {
  const bugs = [];

  //  Runtime JS errors
  if (analysis?.consoleErrors?.length) {
    analysis.consoleErrors.forEach(err => {
      bugs.push({
        title: "Runtime JavaScript Error",
        severity: "High",
        source: "Playwright Analyzer",
        applicationUrl: appUrl,
        status: "Open",

        description:
          "A JavaScript runtime error occurred while the application was running.",

        steps:
          `1. Open the application at ${appUrl}
2. Navigate through the page normally
3. Observe the browser console`,

        expected:
          "The application should run without throwing JavaScript errors.",

        actual:
          `The application throws the following error:\n${err}`
      });
    });
  }

  // Network / API errors
  if (analysis?.networkErrors?.length) {
    analysis.networkErrors.forEach(net => {
      bugs.push({
        title: "API / Network Failure",
        severity: "Medium",
        createdBy: "Playwright Analyzer",
  openedBy: null,
        applicationUrl: appUrl,
        status: "Open",

        description:
          "An API request failed while the application was running.",

        steps:
          `1. Open the application at ${appUrl}
2. Perform the related user action
3. Monitor network requests`,

        expected:
          "The API should return a successful response.",

        actual:
          `Request to ${net.url} failed with status code ${net.status}.`
      });
    });
  }



  // TEMP test bug (remove later)
  bugs.push({
    title: "Intentional Test Bug",
    severity: "High",
    createdBy: "Playwright Analyzer",
    openedBy: null,
    applicationUrl: appUrl,
    status: "Open",

    description:
      "This bug is intentionally generated to validate dashboard integration.",

    steps:
      `1. Open the application at ${appUrl}
2. Trigger analysis from Bug Tracker
3. Review generated issues`,

    expected:
      "The dashboard should correctly display auto-generated bugs.",

    actual:
      "An intentional bug was generated for testing purposes."
  });

  return bugs; // ALWAYS return
}
