export function polishBugText(bug) {
  return {
    ...bug,
    description: bug.description.replace(
      "detected",
      "identified"
    )
  };
}
