import express from "express";
import cors from "cors";
import http from "http";
import { initSocket, emitNewBug } from "./socket.js";
import { analyzeApp } from "./analyzer/playwrightAnalyzer.js";
import { interpretSignals } from "./analyzer/signalInterpreter.js";
import { composeBug } from "./analyzer/bugComposer.js";
import { createBugSignature } from "./analyzer/bugSignature.js";
import { generateStructuredBugReport } from "./ai/bugAI.js";

const app = express();
const server = http.createServer(app);

// Initialize Socket.io with the HTTP wrapper
initSocket(server);

app.use(cors({ origin: "*" }));
app.use(express.json());

const issues = [];
const bugIndex = new Map();

/* AUTOMATIC INTELLIGENT INGESTION */
app.post("/api/bugs/ingest", async (req, res) => {
  try {
    const signal = req.body;
    const interpreted = interpretSignals([signal]);
    if (!interpreted.length) return res.json({ status: "ignored" });

    const item = interpreted[0];
    const signature = createBugSignature(item, signal.url);

    if (bugIndex.has(signature)) {
      return res.json({ status: "duplicate" });
    }

    // CRITICAL: Await the AI enrichment
    const enrichedData = await composeBug(item, signal.url);

    const bug = {
      id: `BUG-${Date.now()}`,
      signature,
      ...enrichedData,
      createdBy: "Auto-AI Monitor",
      status: "Todo",
      createdAt: new Date().toLocaleString(),
      navigationFlow: signal.navigationFlow || null, // Store navigation flow
      navigationSummary: signal.navigationFlow?.summary || null
    };

    bugIndex.set(signature, bug.id);
    issues.unshift(bug);
    emitNewBug(bug);

    res.json({ status: "created", bugId: bug.id });
  } catch (err) {
    console.error("Ingestion failed:", err);
    res.status(500).json({ error: "Internal Error" });
  }
});

/* UPDATE ISSUE STATUS */
app.patch("/api/issues/:id/status", (req, res) => {
  try {
    const { id } = req.params;
    const { status, currentUser } = req.body;

    const issueIndex = issues.findIndex(i => i.id === id);

    if (issueIndex === -1) {
      return res.status(404).json({ error: "Issue not found" });
    }

    const now = new Date().toLocaleString();
    const issue = issues[issueIndex];

    // Update status and track who/when
    issue.status = status;

    if (status === "Open" && !issue.openedBy) {
      issue.openedBy = currentUser ? `${currentUser.empId} - ${currentUser.name}` : "Unknown";
      issue.openedAt = now;
    } else if (status === "Fixed" && !issue.fixedBy) {
      issue.fixedBy = currentUser ? `${currentUser.empId} - ${currentUser.name}` : "Unknown";
      issue.fixedAt = now;
    } else if (status === "Closed") {
      issue.closedAt = now;
    }

    console.log(`✅ Updated issue ${id} to status: ${status}`);
    res.json({ success: true, issue });
  } catch (err) {
    console.error("Status update failed:", err);
    res.status(500).json({ error: err.message });
  }
});

/*ANALYZE APPLICATION (Corrected Loop) */
app.get("/api/analyze", async (req, res) => {
  try {
    const { url } = req.query;
    if (!url) return res.status(400).json({ error: "URL required" });

    const signals = await analyzeApp(url);
    const interpreted = interpretSignals(signals);

    let created = 0;
    let skipped = 0;

    // FIXED: Use for...of instead of forEach to handle await correctly
    for (const item of interpreted) {
      const signature = createBugSignature(item, url);

      if (bugIndex.has(signature)) {
        skipped++;
        continue;
      }

      //  Await AI response before creating the bug object
      const enrichedBugData = await composeBug(item, url);

      const bug = {
        id: `BUG-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        signature,
        ...enrichedBugData,
        createdBy: "AI-Intelligent Analyzer",
        status: "Todo",
        createdAt: new Date().toLocaleString()
      };

      issues.unshift(bug);
      bugIndex.set(signature, bug.id);
      emitNewBug(bug);
      created++;
    }

    res.json({ bugsCreated: created, bugsSkipped: skipped });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "AI Analysis failed" });
  }
});

/* GENERATE STRUCTURED BUG REPORT FROM PLAIN TEXT */
app.post("/api/bugs/generate-report", async (req, res) => {
  try {
    const { plainTextDescription } = req.body;

    if (!plainTextDescription || !plainTextDescription.trim()) {
      return res.status(400).json({ error: "Bug description is required" });
    }

    // Call AI to generate structured bug report
    const bugReport = await generateStructuredBugReport(plainTextDescription);

    res.json({
      success: true,
      report: bugReport
    });
  } catch (err) {
    console.error("Bug report generation failed:", err);
    res.status(500).json({
      error: "Failed to generate bug report. Please try again.",
      details: err.message
    });
  }
});

app.get("/api/issues", (req, res) => res.json(issues));

server.listen(4000, () => {
  console.log("Server & Sockets running on http://localhost:4000");
});