import { Server } from "socket.io";

let io;

export function initSocket(server) {
  io = new Server(server, { 
    cors: { 
      origin: "*", 
      methods: ["GET", "POST"] 
    } 
  });

  io.on("connection", socket => {
    console.log("Dashboard connected:", socket.id);
  });
}

export function emitNewBug(bug) {
  if (!io) return;
  
  io.emit("new-bug", bug);
  console.log("Emitting new bug:", bug.title);
}

export function emitBugUpdated(bug) {
  if (io) {
    io.emit("bug-updated", bug);
  }
}
