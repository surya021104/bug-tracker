export function createBugsFromAnalysis(analysis, appUrl) {
  const bugs = [];

  analysis.consoleErrors.forEach(err => {
    bugs.push({
      title: "Console Runtime Error",
      description: err,
      steps: `1. Open ${appUrl}\n2. Check browser console`,
      expected: "Application should run without console errors",
      actual: err,
      severity: "High",
      status: "Todo",
      createdBy: "Analyzer"
    });
  });

  analysis.networkErrors.forEach(net => {
    bugs.push({
      title: "Network / API Failure",
      description: `Request failed: ${net.url}`,
      steps: `1. Open ${appUrl}\n2. Trigger application actions`,
      expected: "API should respond successfully",
      actual: `${net.url} returned ${net.status}`,
      severity: net.status >= 500 ? "High" : "Medium",
      status: "Todo",
      createdBy: "Analyzer"
    });
  });

  return bugs;
}
